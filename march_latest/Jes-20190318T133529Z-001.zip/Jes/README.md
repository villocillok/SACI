# CS-192-Project
SA/GA Application for OSSS

index
login
signup
logout
mysql_init
view_jobs
home

Faculty Files:
accept_student
basic_paper_input
basic_paper_input_receiver
faculty_login
faculty_receiver
post_job
post_job_receiver
send_message
send_notification
signup_faculty
view_applicants
view_application


Student Files:
apply_job
apply_job_receiver
signup_student
student_login
student_receiver
view_jobs
view_messages
view_notifications

Code structure (most files, not all):
php
html
    head
    body
        header
        page body (includes some php code)
        footer

Issues:
Modal problems
Decline functionality in Faculty view applicants
Absolute-0 suggestion: Ilagay na yung mismong login input box/forms sa index.php header (parang sa fb)

