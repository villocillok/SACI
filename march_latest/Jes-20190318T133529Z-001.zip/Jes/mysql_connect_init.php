<?php
	$user = "root";
	$password = "";
	$host = "localhost";
	$db = "saga";

	$conn = mysqli_connect($host, $user, $password, $db);

?>
