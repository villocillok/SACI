function show_adv_s(){

	var disp = document.getElementById("s_normal").style.display;
	if(disp == "block"){
		document.getElementById("s_normal").style.display = "none";
		document.getElementById("s_advance").style.display = "block";
	}
	else if (disp == "none"){
		document.getElementById("s_normal").style.display = "block";
		document.getElementById("s_advance").style.display = "none";
	}

}

function author_box(){


	var disp = document.getElementById("auth_sel").style.display;
	if(disp == "block"){
		document.getElementById("auth_sel").style.display = "none";
		document.getElementById("new_author_info").style.display = "block";
	}
	else if (disp == "none"){
		document.getElementById("auth_sel").style.display = "block";
		document.getElementById("new_author_info").style.display = "none";
	}
}
