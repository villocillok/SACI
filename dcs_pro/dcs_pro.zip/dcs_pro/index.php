<?php
	include('sql_connect.php');
	if(isset($_POST['submit'])){
		echo $_POST['date'];
	}
?>

<!DOCTYPE HTML>

<html>

<head>
	<meta charset="utf-8">
	<script src="bootstrap4/js/bootstrap.min.js"></script>
	<script src="scripts.js"></script>
	<link rel="stylesheet" href="bootstrap4/css/bootstrap.min.css">
</head>

<body>

DCS Published Papers
<br>
<br>

Toggle Advanced Search

<br>
<br>
<form id="s_normal" method="post" style="display: block">
	Search
	<br>
	<br>
	<input type="text" name="title" placeholder="Title">
	<input type="submit" name="search" value="Submit">

</form>

<form action="add_paper.php" id="s_advance" method="post" style="display: none">
	Advanced Search
	<br>
	<br>
	<table>
	<tbody>
	<tr>
	<td>
	Title:
	</td>
	<td> 
	<input type="text" name="title" placeholder="Title">
	</td>
	</tr>
	<tr>
	<td>
	Author:
	</td>
	<td>
	<input type="text" name="author" placeholder="Author">
	</td>
	</tr>
	<tr>
	<td>
	Date Published:
	</td>
	<td>
	<input type="date" name="date">
	</td>
	</tr>
	<tr>
	<td>
	</td>
	<td>
	<input type="submit" name="adv_search" value="Submit">
	</td>
	</tr>
	</tbody>
	</table>
</form>

<?php
	if (isset($_GET['search'])){
		if (isset($_POST['adv_search'])){
			$query = '
				SELECT * FROM paper WHERE 
				
			';
		}
	}
?>

<br>
<a href="add_paper.php" class="btn btn-primary">
	Add paper
</a>

<br>
<br>

<form>

</form>

<script>
	document.getElementById("s_check_box").checked=false;
</script>

</body>


</html>