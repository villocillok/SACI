<?php

	$VAL_MAPS = array(
			"classification" => array(
					"Conference Paper",
					"Journal",
					"Book Chapter",
					"Book"	
				),
		);
	include("sql_connect.php");
	if(isset($_POST['add'])){
		

		$auth_id = $_POST['authors'];

		if (isset($_POST['new_author_box'])){
		
			$query = '
				INSERT INTO authors (fname, lname, mname) VALUES
				("'.$_POST['na_fname'].'","'.$_POST['na_lname'].'","'.$_POST['na_mname'].'")
			';	

			mysqli_query($conn, $query);
		
			$query = '
				SELECT author_id FROM authors WHERE 
				fname = "'.$_POST['na_fname'].'" AND
				lname = "'.$_POST['na_lname'].'" AND
				mname = "'.$_POST['na_mname'].'"
			';

			$res = mysqli_query($conn, $query);

			$auth_id = mysqli_fetch_assoc($res)['author_id'];
		}

		$query = '
			INSERT INTO papers (
				author_id, 
				title, 
				classification,
				date_published,
				isbn,
				issn,
				doi,
				venue_publication)
			VALUES 
			('.$auth_id.', 
			"'.$_POST['title'].'",
			"'.$VAL_MAPS['classification'][$_POST['classification']].'",
			"'.$_POST['date'].'",
			"'.$_POST['isbn'].'",
			"'.$_POST['issn'].'",
			"'.$_POST['doi'].'",
			"'.$_POST['ven_pub'].'"
			)
		';

		mysqli_query($conn, $query);

	}
?>

<!DOCTYPE HTML>

<html>

<head>
	<meta charset="utf-8">
	<script src="bootstrap4/js/bootstrap.min.js"></script>
	<script src="scripts.js"></script>
	<link rel="stylesheet" href="bootstrap4/css/bootstrap.min.css">
</head>

<body>
<br>
<h3>Add paper</h3>

<form method="POST">
<label for="authors">Author: </label>

<div id="auth_sel" style="display: block;">
<select name="authors">
<?php
	$query = 'SELECT * FROM authors';

	$res = mysqli_query($conn, $query);

	while($row = mysqli_fetch_assoc($res)){
		echo '
			<option value='.$row['author_id'].'>'.$row['lname'].', '.$row['fname'].' '.$row['mname'].'</option>
		';
	}	
?>
</select>
</div>

<label>New Author</label>
<input type="checkbox" id="na_box" name="new_author_box" onchange="author_box()">

<div id="new_author_info" style="display: none">
	<label>First Name: </label>
	<input type="text" name="na_fname" placeholder >
	<label>Last Name: </label>
	<input type="text" name="na_lname" placeholder >
	<label>Middle Name: </label>
	<input type="text" name="na_mname" placeholder >
</div>

<br>

<label for="title">Title: </label>
<input type="text" name="title" placeholder="Title">

<br>

<label>Classification: </label>
<select name="classification">
	<option value=1>Conference Paper</option>
	<option value=2>Journal</option>
	<option value=3>Book Chapter</option>
	<option value=4>Book</option>
</select>

<br>

<label>Date Published: </label>
<input type="date" name="date">

<br>
<label>ISBN: </label>
<input type="text" name="isbn">
<br>

<label>ISSN: </label>
<input type="text" name="issn">

<br>
<label>Date Published: </label>
<select name="local">
	<option value=1>Local</option>
	<option value=2>International</option>
</select>
<br>

<label>DOI: </label>
<input type="text" name="doi">

<br>
<label>Venue Publication: </label>
<input type="text" name="ven_pub">

<br>
<input type="submit" name="add" value="Submit">

</form>

<script>
	document.getElementById("na_box").checked=false;
</script>


</body>

</html>