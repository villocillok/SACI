<?php

	print_r();

?>