<?php

	$user = 'root';
	$password = 'BachtusCentoris111466';
	$host = "127.0.0.1";
	$db = "dcs_prof_papers";

	$conn = mysqli_connect($host, $user, $password, $db);
	
?>