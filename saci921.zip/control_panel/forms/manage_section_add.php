<form data-form="add-section-form">
    <label>Section Type:</label>
    <div class="input-control text full-size">
        <input type="text" name="sections" placeholder="Type the section name here..." autofocus>
    </div>
    <div class="align-right">
        <input type="submit" class="button primary" value="Add">
    </div>
</form>