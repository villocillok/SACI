<form data-form="add-department-form">
    <label>Department Name:</label>
    <div class="input-control text full-size">
        <input type="text" name="departments" placeholder="Type the department name here..." autofocus>
    </div>
    <div class="align-right">
        <input type="submit" class="button primary" value="Add">
    </div>
</form>