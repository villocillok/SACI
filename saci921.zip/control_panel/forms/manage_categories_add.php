<form data-form="add-category-form">
    <label>Category Name:</label>
    <div class="input-control text full-size">
        <input type="text" name="category" placeholder="Type the category name here..." autofocus>
    </div>
    <div class="align-right">
        <input type="submit" class="button primary" value="Add">
    </div>
</form>