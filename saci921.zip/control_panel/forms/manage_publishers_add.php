<form data-form="add-publisher-form">
    <label>Publisher Name:</label>
    <div class="input-control text full-size">
        <input type="text" name="publisher" placeholder="Type the Publiher name here..." autofocus>
    </div>
    <label>Publisher Address:</label>
    <div class="input-control text full-size">
        <input type="text" name="publisherAddress" placeholder="Type the Publisher Address here...">
    </div>
    <label>Contact Number:</label>
    <div class="input-control text full-size">
        <input type="text" name="contactNumber" placeholder="Type the Publisher contact number here...">
    </div>
    
    <div class="align-right">
        <input type="submit" class="button primary" value="Add">
    </div>
</form>