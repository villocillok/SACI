<form data-form="add-author-form">
    <label>Author's First Name:</label>
    <div class="input-control text full-size">
        <input type="text" name="authorFirstName" placeholder="Type the author's First Name here..." autofocus>
    </div>
    <label>Author's Last Name:</label>
    <div class="input-control text full-size">
        <input type="text" name="authorLastName" placeholder="Type the authors's Last Name here...">
    </div>
    <div class="align-right">
        <input type="submit" class="button primary" value="Add">
    </div>
</form>