$(document).ready(function() {
    $('#settled-penalties-table').dataTable();
});