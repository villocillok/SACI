<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Control Panel - Southeast Asian College Inc.</title>
    <link rel="shortcut icon" href="assets/image/Southeast Asian College.png">
    
    <link rel="stylesheet" href="assets/css/metro.min.css">
    <link rel="stylesheet" href="assets/css/metro-icons.min.css">
    <link rel="stylesheet" href="assets/css/metro-responsive.min.css">
    <link rel="stylesheet" href="assets/css/stylesheet.css">

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery.dataTables.min.js"></script>
    <script src="assets/js/metro.min.js"></script>
    <script src="assets/js/select2.min.js"></script>
    <script src="assets/js/script.js"></script>
</head>
<body id="main-body">